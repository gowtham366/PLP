package com.oirs.dao;

public interface IQueryMapper {
	public static final String QUERY_AUTH_USER ="SELECT user_id,role,last_login FROM tbl_user_master WHERE user_id = ? AND password = ?";
	public static final String QUERY_SEARCH_EMPLOYEE = "SELECT employee_id,employee_name,skill,domain,experience_yrs,project_id,rm_id FROM tbl_employee_master WHERE domain = ? AND skill = ? AND experience_yrs = ?";
}
