package com.oirs.bean;

import java.util.Date;

public class ProjectBean {

private String projectId;
private String projectName;
private String projectDesc;
private Date projectStartDate;
private Date projectEndDate;
private String projectRmId;

//Generating getters & Setters
public String getProjectId() {
	return projectId;
}
public void setProjectId(String projectId) {
	this.projectId = projectId;
}
public String getProjectName() {
	return projectName;
}
public void setProjectName(String projectName) {
	this.projectName = projectName;
}
public String getProjectDesc() {
	return projectDesc;
}
public void setProjectDesc(String projectDesc) {
	this.projectDesc = projectDesc;
}
public Date getProjectStartDate() {
	return projectStartDate;
}
public void setProjectStartDate(Date projectStartDate) {
	this.projectStartDate = projectStartDate;
}
public Date getProjectEndDate() {
	return projectEndDate;
}
public void setProjectEndDate(Date projectEndDate) {
	this.projectEndDate = projectEndDate;
}
public String getProjectRmId() {
	return projectRmId;
}
public void setProjectRmId(String projectRmId) {
	this.projectRmId = projectRmId;
}

}
