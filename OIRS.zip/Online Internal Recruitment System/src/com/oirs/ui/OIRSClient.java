/**
 * 
 */
package com.oirs.ui;

import java.util.Scanner;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.ProjectBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.service.IOnlineInternalRecService;
import com.oirs.service.OnlineInternalRecServiceImpl;

/**
 * @author gowthc
 *
 */
public class OIRSClient {

	/**
	 * @param args
	 */
	
	//Creating objects for Bean classes
	EmployeeBean empBean = new EmployeeBean();
	ProjectBean projectBean = new ProjectBean();
	RequisitionBean reqBean = new RequisitionBean();
	
	//Main method
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Online Internal Recruitment System");
		int option = 0;
		String userId;
		String userPass;
		do{
			System.out.println("Select your option\n1.Login\n2.Exit");
			IOnlineInternalRecService service = new OnlineInternalRecServiceImpl();
			switch(option)
			{
			case 1 : {
				do{
					System.out.println("Enter User ID : ");
					userId = scanner.next();
				}while(!(service.isValidUserName(userId)));
				System.out.println("Enter password : ");
				userPass = scanner.next();
				if(service.ValidateUser(userId, userPass))
				{
					System.out.println("Valid User");
				}
				else{
					System.out.println("Invalid UserId or Password");
				}
				break;
				}
			case 2 : 
				break;
			default : System.out.println("Please enter correct choice : ");
				break;
			}
			
			System.out.println("Continue again? Y/N");
		}while(scanner.next().equalsIgnoreCase("Y"));
	}

}
