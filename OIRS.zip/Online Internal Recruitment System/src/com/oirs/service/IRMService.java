package com.oirs.service;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.exception.OIRSException;

public interface IRMService {
	public String raiseRequisition(RequisitionBean reqBean) throws OIRSException;
	public EmployeeBean viewRequestRes(String reqId) throws OIRSException;
	public boolean acceptRes(String empId) throws OIRSException;
	public boolean rejectRes(String empId) throws OIRSException;
	public boolean unassignProject(String empId) throws OIRSException;
	public void generateReport() throws OIRSException;
}
