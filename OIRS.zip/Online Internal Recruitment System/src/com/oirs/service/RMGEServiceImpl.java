package com.oirs.service;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.exception.OIRSException;

public class RMGEServiceImpl implements IRMGEService {

	@Override
	public EmployeeBean searchEmployee(RequisitionBean reqBean)
			throws OIRSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String assignProjectEmp(String empId, String reqId)
			throws OIRSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequisitionBean viewAllRequisitions() throws OIRSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequisitionBean viewRequisition(String rmId) throws OIRSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void generateReport() throws OIRSException {
		// TODO Auto-generated method stub

	}

}
