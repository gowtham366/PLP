package com.oirs.service;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.exception.OIRSException;

public interface IRMGEService {
	public abstract EmployeeBean searchEmployee(RequisitionBean reqBean) throws OIRSException;
	public abstract String assignProjectEmp(String empId, String reqId) throws OIRSException;
	public abstract RequisitionBean viewAllRequisitions() throws OIRSException;
	public abstract RequisitionBean viewRequisition(String rmId) throws OIRSException;
	public void generateReport() throws OIRSException;
}
